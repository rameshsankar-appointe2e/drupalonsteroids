=Whitespace=

* Use spaces. Set your tab stops to 2-space stops.
* Move new block curlies to a new line.