API Docs
========
This folder should include any auto-magic-gen'd or manually-created documentation for your published API. 
If the project is a service, include docs describing your interface and protocols here.

If the project is a library, include header docs.

