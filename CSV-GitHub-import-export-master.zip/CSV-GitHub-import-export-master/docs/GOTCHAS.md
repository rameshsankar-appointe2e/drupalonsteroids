Gotchas
=========

The following are things to be aware of when working with this codebase.

1. Nothing
2. Nothing
3. Nothing

