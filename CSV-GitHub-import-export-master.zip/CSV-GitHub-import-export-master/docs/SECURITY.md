Security
=========

The security concerns and patterns for this project.


Concerns
=========



Patterns
=========


