Docs
======

This directory should be updated in each sprint planning meeting, and will include at least the planned updates for the domain model and UI.

Each build should add incrementally. This doesn't preclude meta-design artifacts from being included in this directory, but the implementation design should be carved up incrementally and built according to the goals and commitment of the sprint.


