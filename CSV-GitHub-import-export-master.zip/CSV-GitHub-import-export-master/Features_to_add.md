Features to add
===============

###Priority Items to Add

1. GUI: it would be great if this could be an icon on the desktop or in The Dock that a user could click and get a dialogue box with the input fields there.
2. Password obfuscation: showing the password is really bad.
3. Key authentication: I don't know if that's an option, but that would negate the need for passwords entirely.
4. Export each issue's labels as separate fields.

###Lower Priority Items (a.k.a. "Wish List") 

1. Drop-down menus: (stretch goal) it'd be swanky if you ran it and it showed you the ogs and repos you have access to and let you choose that way.
2. File picker: (stretch goal) it'd be swanky if, when importing, you ran it and it used the standard OSX file picker to choose your CSV file.
