Product
========

This directory is where your product should live. Treat this as the repo root from an application point of view.

For Yii projects, this would be the location for:

* product
    * yii
    * webapp
    * devops

For Cinder projects, this would be the location for:

* product
    * include
    * resources
    * src
    * vc10
    * xcode

For Akka projects:

* product
    * project
    * src
        * main
        * test

Etc, and so on, and so on.
